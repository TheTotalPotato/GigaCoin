<?xml version="1.0" ?><!DOCTYPE TS><TS language="et" version="2.0">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="+14"/>
        <source>About Bitcoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+39"/>
        <source>&lt;b&gt;Bitcoin Core&lt;/b&gt; version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+57"/>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>⏎
See on eksperimentaalne tarkvara.⏎
⏎
Levitatud MIT/X11 tarkvara litsentsi all, vaata kaasasolevat faili COPYING või http://www.opensource.org/licenses/mit-license.php⏎
⏎
Toode sisaldab OpenSSL Projekti all toodetud tarkvara, mis on kasutamiseks OpenSSL Toolkitis (http://www.openssl.org/) ja Eric Young&apos;i poolt loodud krüptograafilist tarkvara (eay@cryptsoft.com) ning Thomas Bernard&apos;i loodud UPnP tarkvara.</translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="+29"/>
        <source>Copyright</source>
        <translation>Autoriõigus</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The Bitcoin Core developers</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+30"/>
        <source>Double-click to edit address or label</source>
        <translation>Topeltklõps aadressi või märgise muutmiseks</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Create a new address</source>
        <translation>Loo uus aadress</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;New</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+11"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopeeri märgistatud aadress vahemällu</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+52"/>
        <source>C&amp;lose</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="+74"/>
        <source>&amp;Copy Address</source>
        <translation>&amp;Aadressi kopeerimine</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="-41"/>
        <source>Delete the currently selected address from the list</source>
        <translation>Kustuta märgistatud aadress loetelust</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-27"/>
        <source>&amp;Delete</source>
        <translation>&amp;Kustuta</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="-30"/>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+5"/>
        <source>C&amp;hoose</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+6"/>
        <source>Sending addresses</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Receiving addresses</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>These are your Bitcoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Need on sinu Bitcoini aadressid maksete saatmiseks. Müntide saatmisel kontrolli alati summat ning saaja aadressi.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>These are your Bitcoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Copy &amp;Label</source>
        <translation>&amp;Märgise kopeerimine</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Edit</source>
        <translation>&amp;Muuda</translation>
    </message>
    <message>
        <location line="+194"/>
        <source>Export Address List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Komaeraldatud fail (*.csv)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Exporting Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>There was an error trying to save the address list to %1.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="+168"/>
        <source>Label</source>
        <translation>Silt</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Aadress</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>(no label)</source>
        <translation>(silti pole)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="+26"/>
        <source>Passphrase Dialog</source>
        <translation>Salafraasi dialoog</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Enter passphrase</source>
        <translation>Sisesta salafraas</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>New passphrase</source>
        <translation>Uus salafraas</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Repeat new passphrase</source>
        <translation>Korda salafraasi</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="+40"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Sisesta rahakotile uus salafraas.&lt;br/&gt;Palun kasuta salafraasina &lt;b&gt;vähemalt 10 tähte/numbrit/sümbolit&lt;/b&gt;, või &lt;b&gt;vähemalt 8 sõna&lt;/b&gt;.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Encrypt wallet</source>
        <translation>Krüpteeri rahakott</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>See toiming nõuab sinu rahakoti salafraasi.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unlock wallet</source>
        <translation>Tee rahakott lukust lahti.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>See toiming nõuab sinu rahakoti salafraasi.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Decrypt wallet</source>
        <translation>Dekrüpteeri rahakott.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Change passphrase</source>
        <translation>Muuda salafraasi</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Sisesta rahakoti vana ning uus salafraas.</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Confirm wallet encryption</source>
        <translation>Kinnita rahakoti krüpteering</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>Hoiatus: Kui sa kaotad oma, rahakoti krüpteerimisel kasutatud, salafraasi, siis &lt;b&gt;KAOTAD KA KÕIK OMA BITCOINID&lt;/b&gt;!</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Kas soovid oma rahakoti krüpteerida?</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>TÄHTIS: Kõik varasemad rahakoti varundfailid tuleks üle kirjutada äsja loodud krüpteeritud rahakoti failiga. Turvakaalutlustel tühistatakse krüpteerimata rahakoti failid alates uue, krüpteeritud rahakoti, kasutusele võtust.</translation>
    </message>
    <message>
        <location line="+100"/>
        <location line="+24"/>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Hoiatus: Caps Lock on sisse lülitatud!</translation>
    </message>
    <message>
        <location line="-130"/>
        <location line="+58"/>
        <source>Wallet encrypted</source>
        <translation>Rahakott krüpteeritud</translation>
    </message>
    <message>
        <location line="-56"/>
        <source>Bitcoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your bitcoins from being stolen by malware infecting your computer.</source>
        <translation>Bitcoin sulgub krüpteeringu lõpetamiseks. Pea meeles, et rahakoti krüpteerimine ei välista bitcoinide vargust, kui sinu arvuti on nakatunud pahavaraga.</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+7"/>
        <location line="+42"/>
        <location line="+6"/>
        <source>Wallet encryption failed</source>
        <translation>Tõrge rahakoti krüpteerimisel</translation>
    </message>
    <message>
        <location line="-54"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Rahakoti krüpteering ebaõnnestus tõrke tõttu. Sinu rahakotti ei krüpteeritud.</translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+48"/>
        <source>The supplied passphrases do not match.</source>
        <translation>Salafraasid ei kattu.</translation>
    </message>
    <message>
        <location line="-37"/>
        <source>Wallet unlock failed</source>
        <translation>Rahakoti avamine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+11"/>
        <location line="+19"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Rahakoti salafraas ei ole õige.</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Wallet decryption failed</source>
        <translation>Rahakoti dekrüpteerimine ei õnnestunud</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Rahakoti salafraasi muutmine õnnestus.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="+295"/>
        <source>Sign &amp;message...</source>
        <translation>Signeeri &amp;sõnum</translation>
    </message>
    <message>
        <location line="+335"/>
        <source>Synchronizing with network...</source>
        <translation>Võrgusünkimine...</translation>
    </message>
    <message>
        <location line="-407"/>
        <source>&amp;Overview</source>
        <translation>&amp;Ülevaade</translation>
    </message>
    <message>
        <location line="-137"/>
        <source>Node</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+138"/>
        <source>Show general overview of wallet</source>
        <translation>Kuva rahakoti üld-ülevaade</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Tehingud</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Browse transaction history</source>
        <translation>Sirvi tehingute ajalugu</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>E&amp;xit</source>
        <translation>V&amp;älju</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Quit application</source>
        <translation>Väljumine</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Show information about Bitcoin</source>
        <translation>Kuva info Bitcoini kohta</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+2"/>
        <source>About &amp;Qt</source>
        <translation>Teave &amp;Qt kohta</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Show information about Qt</source>
        <translation>Kuva Qt kohta käiv info</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Options...</source>
        <translation>&amp;Valikud...</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Krüpteeri Rahakott</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Varunda Rahakott</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Salafraasi muutmine</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Sending addresses...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Receiving addresses...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Open &amp;URI...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+325"/>
        <source>Importing blocks from disk...</source>
        <translation>Impordi blokid kettalt...</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Reindexing blocks on disk...</source>
        <translation>Kettal olevate blokkide re-indekseerimine...</translation>
    </message>
    <message>
        <location line="-405"/>
        <source>Send coins to a Bitcoin address</source>
        <translation>Saada münte Bitcoini aadressile</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Modify configuration options for Bitcoin</source>
        <translation>Muuda Bitcoini seadeid</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Backup wallet to another location</source>
        <translation>Varunda rahakott teise asukohta</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Rahakoti krüpteerimise salafraasi muutmine</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Debug window</source>
        <translation>&amp;Debugimise aken</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open debugging and diagnostic console</source>
        <translation>Ava debugimise ja diagnostika konsool</translation>
    </message>
    <message>
        <location line="-4"/>
        <source>&amp;Verify message...</source>
        <translation>&amp;Kontrolli sõnumit...</translation>
    </message>
    <message>
        <location line="+430"/>
        <source>Bitcoin</source>
        <translation>Bitcoin</translation>
    </message>
    <message>
        <location line="-643"/>
        <source>Wallet</source>
        <translation>Rahakott</translation>
    </message>
    <message>
        <location line="+146"/>
        <source>&amp;Send</source>
        <translation>&amp;Saada</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Receive</source>
        <translation>&amp;Saama</translation>
    </message>
    <message>
        <location line="+46"/>
        <location line="+2"/>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Näita / Peida</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show or hide the main Window</source>
        <translation>Näita või peida peaaken</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Krüpteeri oma rahakoti privaatvõtmed</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Sign messages with your Bitcoin addresses to prove you own them</source>
        <translation>Omandi tõestamiseks allkirjasta sõnumid oma Bitcoini aadressiga</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Verify messages to ensure they were signed with specified Bitcoin addresses</source>
        <translation>Kinnita sõnumid kindlustamaks et need allkirjastati määratud Bitcoini aadressiga</translation>
    </message>
    <message>
        <location line="+48"/>
        <source>&amp;File</source>
        <translation>&amp;Fail</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Settings</source>
        <translation>&amp;Seaded</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Help</source>
        <translation>&amp;Abi</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Tabs toolbar</source>
        <translation>Vahelehe tööriistariba</translation>
    </message>
    <message>
        <location line="-284"/>
        <location line="+376"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location line="-401"/>
        <source>Bitcoin Core</source>
        <translation>Bitcoini tuumik</translation>
    </message>
    <message>
        <location line="+163"/>
        <source>Request payments (generates QR codes and bitcoin: URIs)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+29"/>
        <location line="+2"/>
        <source>&amp;About Bitcoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+35"/>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Open a bitcoin: URI or payment request</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Command-line options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Show the Bitcoin Core help message to get a list with possible Bitcoin command-line options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+159"/>
        <location line="+5"/>
        <source>Bitcoin client</source>
        <translation>Bitcoini klient</translation>
    </message>
    <message numerus="yes">
        <location line="+142"/>
        <source>%n active connection(s) to Bitcoin network</source>
        <translation><numerusform>%n aktiivne ühendus Bitcoini võrku</numerusform><numerusform>%n aktiivset ühendust Bitcoini võrku</numerusform></translation>
    </message>
    <message>
        <location line="+22"/>
        <source>No block source available...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+12"/>
        <source>Processed %1 of %2 (estimated) blocks of transaction history.</source>
        <translation>Protsessitud %1 (arvutuslikult) tehingu ajaloo blokki %2-st.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Processed %1 blocks of transaction history.</source>
        <translation>Protsessitud %1 tehingute ajaloo blokki.</translation>
    </message>
    <message numerus="yes">
        <location line="+23"/>
        <source>%n hour(s)</source>
        <translation><numerusform>%n tund</numerusform><numerusform>%n tundi</numerusform></translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n day(s)</source>
        <translation><numerusform>%n päev</numerusform><numerusform>%n päeva</numerusform></translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n week(s)</source>
        <translation><numerusform>%n nädal</numerusform><numerusform>%n nädalat</numerusform></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>%1 behind</source>
        <translation>%1 maas</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Last received block was generated %1 ago.</source>
        <translation>Viimane saabunud blokk loodi %1 tagasi.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Peale seda ei ole tehingud veel nähtavad.</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Error</source>
        <translation>Tõrge</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning</source>
        <translation>Hoiatus</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Information</source>
        <translation>Informatsioon</translation>
    </message>
    <message>
        <location line="-85"/>
        <source>Up to date</source>
        <translation>Ajakohane</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Catching up...</source>
        <translation>Jõuan...</translation>
    </message>
    <message>
        <location line="+130"/>
        <source>Sent transaction</source>
        <translation>Saadetud tehing</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Incoming transaction</source>
        <translation>Sisenev tehing</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Kuupäev: %1⏎
Summa: %2⏎
Tüüp: %3⏎
Aadress: %4⏎</translation>
    </message>
    <message>
        <location line="+69"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Rahakott on &lt;b&gt;krüpteeritud&lt;/b&gt; ning hetkel &lt;b&gt;avatud&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Rahakott on &lt;b&gt;krüpteeritud&lt;/b&gt; ning hetkel &lt;b&gt;suletud&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoin.cpp" line="+438"/>
        <source>A fatal error occurred. Bitcoin can no longer continue safely and will quit.</source>
        <translation>Ilmnes kriitiline tõrge. Bitcoin suletakse turvakaalutluste tõttu.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <location filename="../clientmodel.cpp" line="+119"/>
        <source>Network Alert</source>
        <translation>Võrgu Häire</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="+14"/>
        <source>Coin Control Address Selection</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+34"/>
        <source>Quantity:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+29"/>
        <source>Bytes:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+45"/>
        <source>Amount:</source>
        <translation>Summa:</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Priority:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+45"/>
        <source>Fee:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+32"/>
        <source>Low Output:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+48"/>
        <source>After Fee:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+32"/>
        <source>Change:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+63"/>
        <source>(un)select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+13"/>
        <source>Tree mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+16"/>
        <source>List mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+52"/>
        <source>Amount</source>
        <translation>Kogus</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Address</source>
        <translation>Aadress</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Date</source>
        <translation>Kuupäev</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirmations</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Confirmed</source>
        <translation>Kinnitatud</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Priority</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="+42"/>
        <source>Copy address</source>
        <translation>Aadressi kopeerimine</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>Märgise kopeerimine</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+26"/>
        <source>Copy amount</source>
        <translation>Kopeeri summa</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>Copy transaction ID</source>
        <translation>Kopeeri tehingu ID</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Lock unspent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Unlock unspent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+22"/>
        <source>Copy quantity</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Copy fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy after fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy bytes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy priority</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy low output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy change</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+323"/>
        <source>highest</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>higher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>high</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>medium-high</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>medium</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+4"/>
        <source>low-medium</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>low</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>lower</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>lowest</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+11"/>
        <source>(%1 locked)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+31"/>
        <source>none</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+140"/>
        <source>Dust</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+0"/>
        <source>yes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+0"/>
        <source>no</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+10"/>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <location line="+5"/>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-4"/>
        <source>Can vary +/- 1 byte per input.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>This label turns red, if the priority is smaller than &quot;medium&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <location line="+4"/>
        <source>This means a fee of at least %1 is required.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-3"/>
        <source>Amounts below 0.546 times the minimum relay fee are shown as dust.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>This label turns red, if the change is smaller than %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+43"/>
        <location line="+66"/>
        <source>(no label)</source>
        <translation>(silti pole)</translation>
    </message>
    <message>
        <location line="-9"/>
        <source>change from %1 (%2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>(change)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="+14"/>
        <source>Edit Address</source>
        <translation>Muuda aadressi</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Label</source>
        <translation>&amp;Märgis</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+17"/>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-10"/>
        <source>&amp;Address</source>
        <translation>&amp;Aadress</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="+28"/>
        <source>New receiving address</source>
        <translation>Uus sissetulev aadress</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>New sending address</source>
        <translation>Uus väljaminev aadress</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Edit receiving address</source>
        <translation>Sissetulevate aadresside muutmine</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Edit sending address</source>
        <translation>Väljaminevate aadresside muutmine</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Selline aadress on juba olemas: &quot;%1&quot;</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>The entered address &quot;%1&quot; is not a valid Bitcoin address.</source>
        <translation>Sisestatud aadress &quot;%1&quot; ei ole Bitcoinis kehtiv.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Could not unlock wallet.</source>
        <translation>Rahakotti ei avatud</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New key generation failed.</source>
        <translation>Tõrge uue võtme loomisel.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <location filename="../intro.cpp" line="+65"/>
        <source>A new data directory will be created.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+22"/>
        <source>name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <location filename="../forms/helpmessagedialog.ui" line="+19"/>
        <source>Bitcoin Core - Command-line options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="+38"/>
        <source>Bitcoin Core</source>
        <translation>Bitcoini tuumik</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>version</source>
        <translation>versioon</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Usage:</source>
        <translation>Kasutus:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>command-line options</source>
        <translation>käsurea valikud</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>UI options</source>
        <translation>UI valikud</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Keele valik, nt &quot;ee_ET&quot; (vaikeväärtus: system locale)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Start minimized</source>
        <translation>Käivitu tegumiribale</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Käivitamisel teabeakna kuvamine (vaikeväärtus: 1)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Choose data directory on startup (default: 0)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <location filename="../forms/intro.ui" line="+14"/>
        <source>Welcome</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+9"/>
        <source>Welcome to Bitcoin Core.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+26"/>
        <source>As this is the first time the program is launched, you can choose where Bitcoin Core will store its data.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+10"/>
        <source>Bitcoin Core will download and store a copy of the Bitcoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+10"/>
        <source>Use the default data directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Use a custom data directory:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../intro.cpp" line="+85"/>
        <source>Bitcoin</source>
        <translation>Bitcoin</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: Specified data directory &quot;%1&quot; can not be created.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+19"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+9"/>
        <source>GB of free space available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>(of %1GB needed)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <location filename="../forms/openuridialog.ui" line="+14"/>
        <source>Open URI</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+6"/>
        <source>Open payment request from URI or file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+9"/>
        <source>URI:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+11"/>
        <source>Select payment request file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../openuridialog.cpp" line="+47"/>
        <source>Select payment request file to open</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../forms/optionsdialog.ui" line="+14"/>
        <source>Options</source>
        <translation>Valikud</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>&amp;Main</source>
        <translation>%Peamine</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+15"/>
        <source>Pay transaction &amp;fee</source>
        <translation>Tasu tehingu &amp;fee</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Automatically start Bitcoin after logging in to the system.</source>
        <translation>Käivita Bitcoin süsteemi logimisel.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Start Bitcoin on system login</source>
        <translation>&amp;Start Bitcoin sisselogimisel</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+13"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Sea andmebaasi vahemälu suurus MB (vaikeväärtus: 25)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>MB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+27"/>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+13"/>
        <source>Set the number of script verification threads (up to 16, 0 = auto, &lt;0 = leave that many cores free, default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+58"/>
        <source>Connect to the Bitcoin network through a SOCKS proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Connect through SOCKS proxy (default proxy):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+34"/>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+224"/>
        <source>Active command-line options that override above options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+43"/>
        <source>Reset all client options to default.</source>
        <translation>Taasta kõik klientprogrammi seadete vaikeväärtused.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Reset Options</source>
        <translation>&amp;Lähtesta valikud</translation>
    </message>
    <message>
        <location line="-323"/>
        <source>&amp;Network</source>
        <translation>&amp;Võrk</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Automatically open the Bitcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Bitcoini kliendi pordi automaatne avamine ruuteris. Toimib, kui sinu ruuter aktsepteerib UPnP ühendust.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Suuna port &amp;UPnP kaudu</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Proxy &amp;IP:</source>
        <translation>Proxi &amp;IP:</translation>
    </message>
    <message>
        <location line="+32"/>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Proxi port (nt 9050)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>SOCKS &amp;Version:</source>
        <translation>Turva proxi SOCKS &amp;Version:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>Turva proxi SOCKS versioon (nt 5)</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>&amp;Window</source>
        <translation>&amp;Aken</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Minimeeri systray alale.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimeeri systray alale</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Sulgemise asemel minimeeri aken. Selle valiku tegemisel suletakse programm Menüüst &quot;Välju&quot; käsuga.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimeeri sulgemisel</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Display</source>
        <translation>&amp;Kuva</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>User Interface &amp;language:</source>
        <translation>Kasutajaliidese &amp;keel:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>The user interface language can be set here. This setting will take effect after restarting Bitcoin.</source>
        <translation>Kasutajaliidese keele valimise koht. Valik rakendub Bitcoini käivitamisel.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Summade kuvamise &amp;Unit:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Vali liideses ning müntide saatmisel kuvatav vaikimisi alajaotus.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Whether to show Bitcoin addresses in the transaction list or not.</source>
        <translation>Kuvada Bitcoini aadress tehingute loetelus või mitte.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Display addresses in transaction list</source>
        <translation>Tehingute loetelu &amp;Display aadress</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Whether to show coin control features or not.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Display coin &amp;control features (experts only)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+136"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Katkesta</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="+67"/>
        <source>default</source>
        <translation>vaikeväärtus</translation>
    </message>
    <message>
        <location line="+57"/>
        <source>none</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+75"/>
        <source>Confirm options reset</source>
        <translation>Kinnita valikute algseadistamine</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+29"/>
        <source>Client restart required to activate changes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-29"/>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+33"/>
        <source>This change would require a client restart.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+34"/>
        <source>The supplied proxy address is invalid.</source>
        <translation>Sisestatud kehtetu proxy aadress.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="+14"/>
        <source>Form</source>
        <translation>Vorm</translation>
    </message>
    <message>
        <location line="+50"/>
        <location line="+231"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Kuvatav info ei pruugi olla ajakohane. Ühenduse loomisel süngitakse sinu rahakott automaatselt Bitconi võrgustikuga, kuid see toiming on hetkel lõpetamata.</translation>
    </message>
    <message>
        <location line="-155"/>
        <source>Unconfirmed:</source>
        <translation>Kinnitamata:</translation>
    </message>
    <message>
        <location line="-83"/>
        <source>Wallet</source>
        <translation>Rahakott</translation>
    </message>
    <message>
        <location line="+51"/>
        <source>Confirmed:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+16"/>
        <source>Your current spendable balance</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+32"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+16"/>
        <source>Immature:</source>
        <translation>Ebaküps:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Mined balance that has not yet matured</source>
        <translation>Mitte aegunud mine&apos;itud jääk</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Total:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+16"/>
        <source>Your current total balance</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+71"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Uuesti saadetud tehingud&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="+120"/>
        <location line="+1"/>
        <source>out of sync</source>
        <translation>sünkimata</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <location filename="../paymentserver.cpp" line="+403"/>
        <location line="+13"/>
        <source>URI handling</source>
        <translation>URI käsitsemine</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>URI can not be parsed! This can be caused by an invalid Bitcoin address or malformed URI parameters.</source>
        <translation>URI ei suudeta parsida. Põhjuseks võib olla kehtetu Bitcoini aadress või vigased URI parameetrid.</translation>
    </message>
    <message>
        <location line="+96"/>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-221"/>
        <location line="+212"/>
        <location line="+13"/>
        <location line="+95"/>
        <location line="+18"/>
        <location line="+16"/>
        <source>Payment request error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-353"/>
        <source>Cannot start bitcoin: click-to-pay handler</source>
        <translation>Bitcoin ei käivitu: vajuta-maksa toiming</translation>
    </message>
    <message>
        <location line="+58"/>
        <source>Net manager warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Your active proxy doesn&apos;t support SOCKS5, which is required for payment requests via proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+52"/>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+27"/>
        <source>Payment request file handling</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Payment request file can not be read or processed! This can be caused by an invalid payment request file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+73"/>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+59"/>
        <source>Refund from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+43"/>
        <source>Error communicating with %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+24"/>
        <source>Payment request can not be parsed or processed!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+11"/>
        <source>Bad response from server %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+33"/>
        <source>Payment acknowledged</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-11"/>
        <source>Network request error</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../bitcoin.cpp" line="+71"/>
        <location line="+11"/>
        <source>Bitcoin</source>
        <translation>Bitcoin</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-12"/>
        <source>Error: Invalid combination of -regtest and -testnet.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <location filename="../receiverequestdialog.cpp" line="+36"/>
        <source>&amp;Save Image...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Copy Image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+28"/>
        <source>Save QR Code</source>
        <translation>Salvesta QR kood</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>PNG Image (*.png)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="+46"/>
        <source>Client name</source>
        <translation>Kliendi nimi</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+23"/>
        <location line="+26"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+36"/>
        <location line="+23"/>
        <location line="+36"/>
        <location line="+23"/>
        <location line="+23"/>
        <location filename="../rpcconsole.cpp" line="+359"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location line="-223"/>
        <source>Client version</source>
        <translation>Kliendi versioon</translation>
    </message>
    <message>
        <location line="-45"/>
        <source>&amp;Information</source>
        <translation>&amp;Informatsioon</translation>
    </message>
    <message>
        <location line="-10"/>
        <source>Debug window</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+25"/>
        <source>General</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+53"/>
        <source>Using OpenSSL version</source>
        <translation>Kasutan OpenSSL versiooni</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Startup time</source>
        <translation>Käivitamise hetk</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Network</source>
        <translation>Võrgustik</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+23"/>
        <source>Number of connections</source>
        <translation>Ühenduste arv</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Block chain</source>
        <translation>Ploki jada</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Current number of blocks</source>
        <translation>Plokkide hetkearv</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Estimated total blocks</source>
        <translation>Ligikaudne plokkide kogus</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Last block time</source>
        <translation>Viimane ploki aeg</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>&amp;Open</source>
        <translation>&amp;Ava</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>&amp;Console</source>
        <translation>&amp;Konsool</translation>
    </message>
    <message>
        <location line="+72"/>
        <source>&amp;Network Traffic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+52"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+13"/>
        <source>Totals</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+64"/>
        <source>In:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+80"/>
        <source>Out:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-521"/>
        <source>Build date</source>
        <translation>Valmistusaeg</translation>
    </message>
    <message>
        <location line="+206"/>
        <source>Debug log file</source>
        <translation>Debugimise logifail</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Open the Bitcoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Ava Bitcoini logifail praegusest andmekaustast. Toiminguks võib kuluda kuni mõni sekund.</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>Clear console</source>
        <translation>Puhasta konsool</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="-30"/>
        <source>Welcome to the Bitcoin RPC console.</source>
        <translation>Teretulemast Bitcoini RPC konsooli.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Ajaloo sirvimiseks kasuta üles ja alla nooli, ekraani puhastamiseks &lt;b&gt;Ctrl-L&lt;/b&gt;.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Ülevaateks võimalikest käsklustest trüki &lt;b&gt;help&lt;/b&gt;.</translation>
    </message>
    <message>
        <location line="+122"/>
        <source>%1 B</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 KB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 MB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 GB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>%1 m</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+5"/>
        <source>%1 h</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 h %2 m</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="+83"/>
        <source>&amp;Amount:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-13"/>
        <source>&amp;Label:</source>
        <translation>&amp;Märgis</translation>
    </message>
    <message>
        <location line="-34"/>
        <source>&amp;Message:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-17"/>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+27"/>
        <source>An optional label to associate with the new receiving address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Bitcoin network.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+39"/>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+17"/>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Clear</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+36"/>
        <source>&amp;Request payment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+47"/>
        <source>Requested payments</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+16"/>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Show</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+11"/>
        <source>Remove the selected entries from the list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Remove</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <location filename="../forms/receiverequestdialog.ui" line="+29"/>
        <source>QR Code</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+46"/>
        <source>Copy &amp;URI</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Copy &amp;Address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Save Image...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="+56"/>
        <source>Request payment to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+6"/>
        <source>Payment information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>URI</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Address</source>
        <translation>Aadress</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Amount</source>
        <translation>Kogus</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Label</source>
        <translation>Silt</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Message</source>
        <translation>Sõnum</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Tulemuseks on liiga pikk URL, püüa lühendada märgise/teate teksti.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error encoding URI into QR Code.</source>
        <translation>Tõrge URI&apos;st QR koodi loomisel</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="+24"/>
        <source>Date</source>
        <translation>Kuupäev</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Label</source>
        <translation>Silt</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Message</source>
        <translation>Sõnum</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Amount</source>
        <translation>Kogus</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>(no label)</source>
        <translation>(silti pole)</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>(no message)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="+14"/>
        <location filename="../sendcoinsdialog.cpp" line="+381"/>
        <location line="+80"/>
        <source>Send Coins</source>
        <translation>Müntide saatmine</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>Coin Control Features</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+20"/>
        <source>Inputs...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>automatically selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+19"/>
        <source>Insufficient funds!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+89"/>
        <source>Quantity:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+35"/>
        <source>Bytes:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+48"/>
        <source>Amount:</source>
        <translation>Summa:</translation>
    </message>
    <message>
        <location line="+32"/>
        <source>Priority:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+48"/>
        <source>Fee:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+32"/>
        <source>Low Output:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+48"/>
        <source>After Fee:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+32"/>
        <source>Change:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+44"/>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Custom change address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+115"/>
        <source>Send to multiple recipients at once</source>
        <translation>Saatmine mitmele korraga</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Add &amp;Recipient</source>
        <translation>Lisa &amp;Saaja</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Clear &amp;All</source>
        <translation>Puhasta &amp;Kõik</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Balance:</source>
        <translation>Jääk:</translation>
    </message>
    <message>
        <location line="+41"/>
        <source>Confirm the send action</source>
        <translation>Saatmise kinnitamine</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>S&amp;end</source>
        <translation>S&amp;aada</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="-228"/>
        <source>Confirm send coins</source>
        <translation>Müntide saatmise kinnitamine</translation>
    </message>
    <message>
        <location line="-74"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+4"/>
        <source>%1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-136"/>
        <source>Enter a Bitcoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Sisesta Bitcoini aadress (nt: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Copy quantity</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>Kopeeri summa</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy after fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy bytes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy priority</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy low output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy change</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+170"/>
        <source>Total Amount %1 (= %2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>or</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+202"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Saaja aadress ei ole kehtiv, palun kontrolli.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Makstav summa peab olema suurem kui 0.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The amount exceeds your balance.</source>
        <translation>Summa ületab jäägi.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Summa koos tehingu tasuga %1 ületab sinu jääki.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Ühe saatmisega topelt-adressaati olla ei tohi.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Transaction creation failed!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+4"/>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+112"/>
        <source>Warning: Invalid Bitcoin address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+21"/>
        <source>(no label)</source>
        <translation>(silti pole)</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>Warning: Unknown change address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-366"/>
        <source>Are you sure you want to send?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+9"/>
        <source>added as transaction fee</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+170"/>
        <source>Payment request expired</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+8"/>
        <source>Invalid payment address %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="+131"/>
        <location line="+521"/>
        <location line="+536"/>
        <source>A&amp;mount:</source>
        <translation>S&amp;umma:</translation>
    </message>
    <message>
        <location line="-1152"/>
        <source>Pay &amp;To:</source>
        <translation>Maksa &amp;:</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to send the payment to (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Tehingu saaja aadress (nt: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="+30"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Aadressiraamatusse sisestamiseks märgista aadress</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="+57"/>
        <source>&amp;Label:</source>
        <translation>&amp;Märgis</translation>
    </message>
    <message>
        <location line="-50"/>
        <source>Choose previously used address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-40"/>
        <source>This is a normal payment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+50"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Paste address from clipboard</source>
        <translation>Kleebi aadress vahemälust</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+524"/>
        <location line="+536"/>
        <source>Remove this entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-1008"/>
        <source>Message:</source>
        <translation>Sõnum:</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>A message that was attached to the Bitcoin URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin network.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+958"/>
        <source>This is a verified payment request.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-991"/>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+459"/>
        <source>This is an unverified payment request.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+18"/>
        <location line="+532"/>
        <source>Pay To:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-498"/>
        <location line="+536"/>
        <source>Memo:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="+1"/>
        <source>Enter a Bitcoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Sisesta Bitcoini aadress (nt: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <location filename="../utilitydialog.cpp" line="+48"/>
        <source>Bitcoin Core is shutting down...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="+14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signatuurid - Allkirjasta / Kinnita Sõnum</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Allkirjastamise teade</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Omandiõigsuse tõestamiseks saad sõnumeid allkirjastada oma aadressiga. Ettevaatust petturitega, kes üritavad saada sinu allkirja endale saada. Allkirjasta ainult korralikult täidetud avaldusi, millega nõustud.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to sign the message with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Sõnumi signeerimise aadress (nt: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+213"/>
        <source>Choose previously used address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-203"/>
        <location line="+213"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="-203"/>
        <source>Paste address from clipboard</source>
        <translation>Kleebi aadress vahemälust</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Enter the message you want to sign here</source>
        <translation>Sisesta siia allkirjastamise sõnum</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Signature</source>
        <translation>Signatuur</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopeeri praegune signatuur vahemällu</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Sign the message to prove you own this Bitcoin address</source>
        <translation>Allkirjasta sõnum Bitcoini aadressi sulle kuulumise tõestamiseks</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sign &amp;Message</source>
        <translation>Allkirjasta &amp;Sõnum</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all sign message fields</source>
        <translation>Tühjenda kõik sõnumi allkirjastamise väljad</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+146"/>
        <source>Clear &amp;All</source>
        <translation>Puhasta &amp;Kõik</translation>
    </message>
    <message>
        <location line="-87"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Kinnita Sõnum</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Kinnitamiseks sisesta allkirjastamise aadress, sõnum (kindlasti kopeeri täpselt ka reavahetused, tühikud, tabulaatorid jms) ning allolev signatuur.</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>The address the message was signed with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Aadress, millega sõnum allkirjastati (nt: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Verify the message to ensure it was signed with the specified Bitcoin address</source>
        <translation>Kinnita sõnum tõestamaks selle allkirjastatust määratud Bitcoini aadressiga.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Verify &amp;Message</source>
        <translation>Kinnita &amp;Sõnum</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all verify message fields</source>
        <translation>Tühjenda kõik sõnumi kinnitamise väljad</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="+29"/>
        <location line="+3"/>
        <source>Enter a Bitcoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Sisesta Bitcoini aadress (nt: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Signatuuri genereerimiseks vajuta &quot;Allkirjasta Sõnum&quot;</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Enter Bitcoin signature</source>
        <translation>Sisesta Bitcoini allkiri</translation>
    </message>
    <message>
        <location line="+84"/>
        <location line="+81"/>
        <source>The entered address is invalid.</source>
        <translation>Sisestatud aadress ei kehti.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+8"/>
        <location line="+73"/>
        <location line="+8"/>
        <source>Please check the address and try again.</source>
        <translation>Palun kontrolli aadressi ning proovi uuesti.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+81"/>
        <source>The entered address does not refer to a key.</source>
        <translation>Sisestatud aadress ei viita võtmele.</translation>
    </message>
    <message>
        <location line="-73"/>
        <source>Wallet unlock was cancelled.</source>
        <translation>Rahakoti avamine katkestati.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Private key for the entered address is not available.</source>
        <translation>Sisestatud aadressi privaatvõti ei ole saadaval.</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Message signing failed.</source>
        <translation>Sõnumi signeerimine ebaõnnestus.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message signed.</source>
        <translation>Sõnum signeeritud.</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>The signature could not be decoded.</source>
        <translation>Signatuuri ei õnnestunud dekodeerida.</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+13"/>
        <source>Please check the signature and try again.</source>
        <translation>Palun kontrolli signatuuri ning proovi uuesti.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The signature did not match the message digest.</source>
        <translation>Signatuur ei kattunud sõnumi kokkuvõttega.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Message verification failed.</source>
        <translation>Sõnumi kontroll ebaõnnestus.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message verified.</source>
        <translation>Sõnum kontrollitud.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <location filename="../splashscreen.cpp" line="+28"/>
        <source>Bitcoin Core</source>
        <translation>Bitcoini tuumik</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>The Bitcoin Core developers</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>[testnet]</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <location filename="../trafficgraphwidget.cpp" line="+79"/>
        <source>KB/s</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="+28"/>
        <source>Open until %1</source>
        <translation>Avatud kuni %1</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>%1/offline</source>
        <translation>%/1offline&apos;is</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1/unconfirmed</source>
        <translation>%1/kinnitamata</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 confirmations</source>
        <translation>%1 kinnitust</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Status</source>
        <translation>Staatus</translation>
    </message>
    <message numerus="yes">
        <location line="+7"/>
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, levita läbi %n node&apos;i</numerusform><numerusform>, levita läbi %n node&apos;i</numerusform></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Date</source>
        <translation>Kuupäev</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Source</source>
        <translation>Allikas</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Generated</source>
        <translation>Genereeritud</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+17"/>
        <source>From</source>
        <translation>Saatja</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+22"/>
        <location line="+58"/>
        <source>To</source>
        <translation>Saaja</translation>
    </message>
    <message>
        <location line="-77"/>
        <location line="+2"/>
        <source>own address</source>
        <translation>oma aadress</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>label</source>
        <translation>märgis</translation>
    </message>
    <message>
        <location line="+37"/>
        <location line="+12"/>
        <location line="+45"/>
        <location line="+17"/>
        <location line="+53"/>
        <source>Credit</source>
        <translation>Krediit</translation>
    </message>
    <message numerus="yes">
        <location line="-125"/>
        <source>matures in %n more block(s)</source>
        <translation><numerusform>aegub %n bloki pärast</numerusform><numerusform>aegub %n bloki pärast</numerusform></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>not accepted</source>
        <translation>mitte aktsepteeritud</translation>
    </message>
    <message>
        <location line="+44"/>
        <location line="+8"/>
        <location line="+15"/>
        <location line="+53"/>
        <source>Debit</source>
        <translation>Deebet</translation>
    </message>
    <message>
        <location line="-62"/>
        <source>Transaction fee</source>
        <translation>Tehingu tasu</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Net amount</source>
        <translation>Neto summa</translation>
    </message>
    <message>
        <location line="+6"/>
        <location line="+9"/>
        <source>Message</source>
        <translation>Sõnum</translation>
    </message>
    <message>
        <location line="-7"/>
        <source>Comment</source>
        <translation>Kommentaar</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transaction ID</source>
        <translation>Tehingu ID</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Merchant</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+8"/>
        <source>Debug information</source>
        <translation>Debug&apos;imise info</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Transaction</source>
        <translation>Tehing</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Inputs</source>
        <translation>Sisendid</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Amount</source>
        <translation>Kogus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>true</source>
        <translation>õige</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>false</source>
        <translation>vale</translation>
    </message>
    <message>
        <location line="-232"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, veel esitlemata</translation>
    </message>
    <message numerus="yes">
        <location line="-35"/>
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Avaneb %n bloki pärast</numerusform><numerusform>Avaneb %n bloki pärast</numerusform></translation>
    </message>
    <message>
        <location line="+70"/>
        <source>unknown</source>
        <translation>tundmatu</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="+14"/>
        <source>Transaction details</source>
        <translation>Tehingu üksikasjad</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Paan kuvab tehingu detailid</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="+234"/>
        <source>Date</source>
        <translation>Kuupäev</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Type</source>
        <translation>Tüüp</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Aadress</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Amount</source>
        <translation>Kogus</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <location line="+16"/>
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Avaneb %n bloki pärast</numerusform><numerusform>Avaneb %n bloki pärast</numerusform></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Open until %1</source>
        <translation>Avatud kuni %1</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Ühenduseta (%1 kinnitust)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Kinnitamata (%1/%2 kinnitust)</translation>
    </message>
    <message>
        <location line="-22"/>
        <location line="+25"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Kinnitatud (%1 kinnitust)</translation>
    </message>
    <message>
        <location line="-22"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Antud klotsi pole saanud ükski osapool ning tõenäoliselt seda ei aktsepteerita!</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated but not accepted</source>
        <translation>Loodud, kuid aktsepteerimata</translation>
    </message>
    <message>
        <location line="+62"/>
        <source>Received with</source>
        <translation>Saadud koos</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Received from</source>
        <translation>Kellelt saadud</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sent to</source>
        <translation>Saadetud</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Payment to yourself</source>
        <translation>Makse iseendale</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Mined</source>
        <translation>Mine&apos;itud</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <location line="+199"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Tehingu staatus. Kinnituste arvu kuvamiseks liigu hiire noolega selle peale.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Tehingu saamise kuupäev ning kellaaeg.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type of transaction.</source>
        <translation>Tehingu tüüp.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Destination address of transaction.</source>
        <translation>Tehingu saaja aadress.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Jäägile lisatud või eemaldatud summa.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="+57"/>
        <location line="+16"/>
        <source>All</source>
        <translation>Kõik</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Today</source>
        <translation>Täna</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This week</source>
        <translation>Jooksev nädal</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This month</source>
        <translation>Jooksev kuu</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Last month</source>
        <translation>Eelmine kuu</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This year</source>
        <translation>Jooksev aasta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Range...</source>
        <translation>Ulatus...</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Received with</source>
        <translation>Saadud koos</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Sent to</source>
        <translation>Saadetud</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>To yourself</source>
        <translation>Iseendale</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Mined</source>
        <translation>Mine&apos;itud</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Other</source>
        <translation>Muu</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Enter address or label to search</source>
        <translation>Otsimiseks sisesta märgis või aadress</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Min amount</source>
        <translation>Vähim summa</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Copy address</source>
        <translation>Aadressi kopeerimine</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>Märgise kopeerimine</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>Kopeeri summa</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy transaction ID</source>
        <translation>Kopeeri tehingu ID</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit label</source>
        <translation>Märgise muutmine</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show transaction details</source>
        <translation>Kuva tehingu detailid</translation>
    </message>
    <message>
        <location line="+142"/>
        <source>Export Transaction History</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+19"/>
        <source>Exporting Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+0"/>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+4"/>
        <source>Exporting Successful</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+0"/>
        <source>The transaction history was successfully saved to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-22"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Komaeraldatud fail (*.csv)</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Confirmed</source>
        <translation>Kinnitatud</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date</source>
        <translation>Kuupäev</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type</source>
        <translation>Tüüp</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Label</source>
        <translation>Silt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Address</source>
        <translation>Aadress</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Amount</source>
        <translation>Kogus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location line="+107"/>
        <source>Range:</source>
        <translation>Ulatus:</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>to</source>
        <translation>saaja</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <location filename="../walletframe.cpp" line="+26"/>
        <source>No wallet has been loaded.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="+245"/>
        <source>Send Coins</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <location filename="../walletview.cpp" line="+43"/>
        <source>&amp;Export</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+181"/>
        <source>Backup Wallet</source>
        <translation>Varundatud Rahakott</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Wallet Data (*.dat)</source>
        <translation>Rahakoti andmed (*.dat)</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Backup Failed</source>
        <translation>Varundamine nurjus</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+4"/>
        <source>The wallet data was successfully saved to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+0"/>
        <source>Backup Successful</source>
        <translation>Varundamine õnnestus</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="+221"/>
        <source>Usage:</source>
        <translation>Kasutus:</translation>
    </message>
    <message>
        <location line="-54"/>
        <source>List commands</source>
        <translation>Käskluste loetelu</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Get help for a command</source>
        <translation>Käskluste abiinfo</translation>
    </message>
    <message>
        <location line="+26"/>
        <source>Options:</source>
        <translation>Valikud:</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Specify configuration file (default: bitcoin.conf)</source>
        <translation>Täpsusta sätete fail (vaikimisi: bitcoin.conf)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Specify pid file (default: bitcoind.pid)</source>
        <translation>Täpsusta PID fail (vaikimisi: bitcoin.pid)</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Specify data directory</source>
        <translation>Täpsusta andmekataloog</translation>
    </message>
    <message>
        <location line="-9"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Sea andmebaasi vahemälu suurus MB (vaikeväärtus: 25)</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Listen for connections on &lt;port&gt; (default: 8333 or testnet: 18333)</source>
        <translation>Kuula ühendusi pordil &lt;port&gt; (vaikeväärtus: 8333 või testnet: 18333)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Säilita vähemalt &lt;n&gt; ühendust peeridega (vaikeväärtus: 125)</translation>
    </message>
    <message>
        <location line="-51"/>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Peeri aadressi saamiseks ühendu korraks node&apos;iga</translation>
    </message>
    <message>
        <location line="+84"/>
        <source>Specify your own public address</source>
        <translation>Täpsusta enda avalik aadress</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Ulakate peeride valulävi (vaikeväärtus: 100)</translation>
    </message>
    <message>
        <location line="-148"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Mitme sekundi pärast ulakad peerid tagasi võivad tulla (vaikeväärtus: 86400)</translation>
    </message>
    <message>
        <location line="-36"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>RPC pordi %u kuulamiseks seadistamisel ilmnes viga IPv4&apos;l: %s</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 8332 or testnet: 18332)</source>
        <translation>Kuula JSON-RPC ühendusel seda porti &lt;port&gt; (vaikeväärtus: 8332 või testnet: 18332)</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Luba käsurea ning JSON-RPC käsklusi</translation>
    </message>
    <message>
        <location line="+80"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Tööta taustal ning aktsepteeri käsklusi</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>Use the test network</source>
        <translation>Testvõrgu kasutamine</translation>
    </message>
    <message>
        <location line="-118"/>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Luba välisühendusi (vaikeväärtus: 1 kui puudub -proxy või -connect)</translation>
    </message>
    <message>
        <location line="-95"/>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=bitcoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;Bitcoin Alert&quot; admin@foo.com
</source>
        <translation>%s, sul tuleb rpcpassword määrata seadete failis:
%s
Soovitatav on kasutada järgmist juhuslikku parooli:
rpcuser=bitcoinrpc
rpcpassword=%s
(seda parooli ei pea meeles pidama)
Kasutajanimi ning parool EI TOHI kattuda.
Kui faili ei leita, loo see ainult-omaniku-loetavas failiõigustes .
Soovitatav on seadistada tõrgete puhul teavitus;
nt: alertnotify=echo %%s | email -s &quot;Bitcoin Alert&quot; admin@foo.com
</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Acceptable ciphers (default: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+5"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>RPC pordi %u kuulamiseks seadistamisel ilmnes viga IPv6&apos;l, lülitumine tagasi IPv4&apos;le : %s</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Määratud aadressiga sidumine ning sellelt kuulamine. IPv6 jaoks kasuta vormingut [host]:port</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot obtain a lock on data directory %s. Bitcoin is probably already running.</source>
        <translation>Ei suuda määrata ainuõigust andmekaustale %s. Tõenäolisel on Bitcoin juba avatud.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly. This is intended for regression testing tools and app development.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+4"/>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Tõrge: Tehingust keelduti! Põhjuseks võib olla juba kulutatud mündid, nt kui wallet.dat fail koopias kulutatid mündid, kuid ei märgitud neid siin vastavalt.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation>Tõrge: Selle tehingu jaoks on nõutav lisatasu vähemalt %s. Põhjuseks võib olla summa suurus, keerukus või hiljuti saadud summade kasutamine!</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Käivita käsklus, kui rahakoti tehing muutub (%s cmd&apos;s muudetakse TxID&apos;ks)</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>See on test-versioon - kasutamine omal riisikol - ära kasuta mining&apos;uks ega kaupmeeste programmides</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: -proxy)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Hoiatus: -paytxfee on seatud väga kõrgeks! See on sinu poolt makstav tehingu lisatasu.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong Bitcoin will not work properly.</source>
        <translation>Hoiatus: Palun kontrolli oma arvuti kuupäeva/kellaaega! Kui arvuti kell on vale, siis Bitcoin ei tööta korralikult</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Hoiatus: ilmnes tõrge wallet.dat faili lugemisel! Võtmed on terved, kuid tehingu andmed või aadressiraamatu kirjed võivad olla kadunud või vigased.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Hoiatus: toimus wallet.dat faili andmete päästmine! Originaal wallet.dat nimetati kaustas %s ümber wallet.{ajatempel}.bak&apos;iks, jäägi või tehingute ebakõlade puhul tuleks teha backup&apos;ist taastamine.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&lt;category&gt; can be:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+6"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Püüa vigasest wallet.dat failist taastada turvavõtmed</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bitcoin Core Daemon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Bitcoin RPC client version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Block creation options:</source>
        <translation>Blokeeri loomise valikud:</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Connect only to the specified node(s)</source>
        <translation>Ühendu ainult määratud node&apos;i(de)ga</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Connect through SOCKS proxy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Connect to JSON-RPC on &lt;port&gt; (default: 8332 or testnet: 18332)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Corrupted block database detected</source>
        <translation>Tuvastati vigane bloki andmebaas</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Leia oma IP aadress (vaikeväärtus: 1, kui kuulatakse ning puudub -externalip)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Kas soovid bloki andmebaasi taastada?</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error initializing block database</source>
        <translation>Tõrge bloki andmebaasi käivitamisel</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Tõrge rahakoti keskkonna %s käivitamisel!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error loading block database</source>
        <translation>Tõrge bloki baasi lugemisel</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error opening block database</source>
        <translation>Tõrge bloki andmebaasi avamisel</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error: Disk space is low!</source>
        <translation>Tõrge: liiga vähe kettaruumi!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Tõrge: Rahakott on lukus, tehingu loomine ei ole võimalik!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: system error: </source>
        <translation>Tõrge: süsteemi tõrge:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Pordi kuulamine nurjus. Soovikorral kasuta -listen=0.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to read block info</source>
        <translation>Tõrge bloki sisu lugemisel</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to read block</source>
        <translation>Bloki lugemine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to sync block index</source>
        <translation>Bloki indeksi sünkimine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block index</source>
        <translation>Bloki indeksi kirjutamine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block info</source>
        <translation>Bloki sisu kirjutamine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block</source>
        <translation>Tõrge bloki sisu kirjutamisel</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write file info</source>
        <translation>Tõrge faili info kirjutamisel</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write to coin database</source>
        <translation>Tõrge mündi andmebaasi kirjutamisel</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write transaction index</source>
        <translation>Tehingu indeksi kirjutamine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write undo data</source>
        <translation>Tagasivõtmise andmete kirjutamine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Fee per kB to add to transactions you send</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Find peers using DNS lookup (default: 1 unless -connect)</source>
        <translation>Otsi DNS&apos;i lookup&apos;i kastavaid peere (vaikeväärtus: 1, kui mitte -connect)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Generate coins (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>How many blocks to check at startup (default: 288, 0 = all)</source>
        <translation>Käivitamisel kontrollitavate blokkide arv (vaikeväärtus: 288, 0=kõik)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>How thorough the block verification is (0-4, default: 3)</source>
        <translation>Blokkide kontrollimise põhjalikkus (0-4, vaikeväärtus: 3)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+15"/>
        <source>Not enough file descriptors available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+5"/>
        <source>Prepend debug output with timestamp (default: 1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>RPC client options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Taasta bloki jada indeks blk000??.dat failist</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Select SOCKS version for -proxy (4 or 5, default: 5)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Send command to Bitcoin server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation>Määra RPC kõnede haldurite arv (vaikeväärtus: 4)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Specify wallet file (within data directory)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Start Bitcoin server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+3"/>
        <source>This is intended for regression testing tools and app development.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+10"/>
        <source>Usage (deprecated, use bitcoin-cli):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+7"/>
        <source>Verifying blocks...</source>
        <translation>Kontrollin blokke...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Verifying wallet...</source>
        <translation>Kontrollin rahakotti...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Wait for RPC server to start</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Wallet %s resides outside data directory %s</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Wallet options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Warning: Deprecated argument -debugnet ignored, use -debug=net</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="-79"/>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Impordi blokid välisest blk000??.dat failist</translation>
    </message>
    <message>
        <location line="-105"/>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+14"/>
        <source>Output debugging information (default: 0, supplying &lt;category&gt; is optional)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Set the number of script verification threads (up to 16, 0 = auto, &lt;0 = leave that many cores free, default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+89"/>
        <source>Information</source>
        <translation>Informatsioon</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+8"/>
        <source>Maintain a full transaction index (default: 0)</source>
        <translation>Säilita kogu tehingu indeks (vaikeväärtus: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>Maksimaalne saamise puhver -connection kohta , &lt;n&gt;*1000 baiti (vaikeväärtus: 5000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>Maksimaalne saatmise puhver -connection kohta , &lt;n&gt;*1000 baiti (vaikeväärtus: 1000)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Only accept block chain matching built-in checkpoints (default: 1)</source>
        <translation>Tunnusta ainult sisseehitatud turvapunktidele vastavaid bloki jadu (vaikeväärtus: 1)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>Ühenda ainult node&apos;idega &lt;net&gt; võrgus (IPv4, IPv6 või Tor)</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>SSL valikud: (vaata Bitcoini Wikist või SSL sätete juhendist)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Saada jälitus/debug, debug.log faili asemel, konsooli</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>Sea minimaalne bloki suurus baitides (vaikeväärtus: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Kahanda programmi käivitamisel debug.log faili (vaikeväärtus: 1, kui ei ole -debug)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Signing transaction failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+2"/>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>Sea ühenduse timeout millisekundites (vaikeväärtus: 5000)</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>System error: </source>
        <translation>Süsteemi tõrge:</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Transaction amount too small</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Transaction amounts must be positive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+1"/>
        <source>Transaction too large</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location line="+8"/>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>Kasuta kuulatava pordi määramiseks UPnP ühendust (vaikeväärtus: 0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Kasuta kuulatava pordi määramiseks UPnP ühendust (vaikeväärtus: 1, kui kuulatakse)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Username for JSON-RPC connections</source>
        <translation>JSON-RPC ühenduste kasutajatunnus</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Warning</source>
        <translation>Hoiatus</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Hoiatus: versioon on aegunud, uuendus on nõutav!</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>version</source>
        <translation>versioon</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat fail on katki, päästmine ebaõnnestus</translation>
    </message>
    <message>
        <location line="-58"/>
        <source>Password for JSON-RPC connections</source>
        <translation>JSON-RPC ühenduste salasõna</translation>
    </message>
    <message>
        <location line="-70"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>JSON-RPC ühenduste lubamine kindla IP pealt</translation>
    </message>
    <message>
        <location line="+80"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Saada käsklusi node&apos;ile IP&apos;ga &lt;ip&gt; (vaikeväärtus: 127.0.0.1)</translation>
    </message>
    <message>
        <location line="-132"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Käivita käsklus, kui parim plokk muutub (käskluse %s asendatakse ploki hash&apos;iga)</translation>
    </message>
    <message>
        <location line="+161"/>
        <source>Upgrade wallet to latest format</source>
        <translation>Uuenda rahakott uusimasse vormingusse</translation>
    </message>
    <message>
        <location line="-24"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Sea võtmete hulgaks &lt;n&gt; (vaikeväärtus: 100)</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Otsi ploki jadast rahakoti kadunud tehinguid</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Kasuta JSON-RPC ühenduste jaoks OpenSSL&apos;i (https)</translation>
    </message>
    <message>
        <location line="-30"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Serveri sertifikaadifail (vaikeväärtus: server.cert)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Serveri privaatvõti (vaikeväärtus: server.pem)</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>This help message</source>
        <translation>Käesolev abitekst</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Selle arvutiga ei ole võimalik siduda %s külge (katse nurjus %d, %s tõttu)</translation>
    </message>
    <message>
        <location line="-107"/>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>-addnode, -seednode ja -connect tohivad kasutada DNS lookup&apos;i</translation>
    </message>
    <message>
        <location line="+60"/>
        <source>Loading addresses...</source>
        <translation>Aadresside laadimine...</translation>
    </message>
    <message>
        <location line="-37"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Viga wallet.dat käivitamisel. Vigane rahakkott</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error loading wallet.dat: Wallet requires newer version of Bitcoin</source>
        <translation>Viga wallet.dat käivitamisel: Rahakott nõuab Bitcoini uusimat versiooni</translation>
    </message>
    <message>
        <location line="+98"/>
        <source>Wallet needed to be rewritten: restart Bitcoin to complete</source>
        <translation>Rahakott tuli ümberkirjutada: toimingu lõpetamiseks taaskäivita Bitcoin</translation>
    </message>
    <message>
        <location line="-100"/>
        <source>Error loading wallet.dat</source>
        <translation>Viga wallet.dat käivitamisel</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Vigane -proxi aadress: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Kirjeldatud tundmatu võrgustik -onlynet&apos;is: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>Küsitud tundmatu -socks proxi versioon: %i</translation>
    </message>
    <message>
        <location line="-101"/>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>Tundmatu -bind aadress: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>Tundmatu -externalip aadress: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+48"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>-paytxfee=&lt;amount&gt; jaoks vigane kogus: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount</source>
        <translation>Kehtetu summa</translation>
    </message>
    <message>
        <location line="-6"/>
        <source>Insufficient funds</source>
        <translation>Liiga suur summa</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Loading block index...</source>
        <translation>Klotside indeksi laadimine...</translation>
    </message>
    <message>
        <location line="-62"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Lisa node ning hoia ühendus avatud</translation>
    </message>
    <message>
        <location line="-32"/>
        <source>Unable to bind to %s on this computer. Bitcoin is probably already running.</source>
        <translation>%s&apos;ga ei ole võimalik sellest arvutist siduda. Bitcoin juba töötab.</translation>
    </message>
    <message>
        <location line="+95"/>
        <source>Loading wallet...</source>
        <translation>Rahakoti laadimine...</translation>
    </message>
    <message>
        <location line="-56"/>
        <source>Cannot downgrade wallet</source>
        <translation>Rahakoti vanandamine ebaõnnestus</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot write default address</source>
        <translation>Tõrge vaikimisi aadressi kirjutamisel</translation>
    </message>
    <message>
        <location line="+67"/>
        <source>Rescanning...</source>
        <translation>Üleskaneerimine...</translation>
    </message>
    <message>
        <location line="-58"/>
        <source>Done loading</source>
        <translation>Laetud</translation>
    </message>
    <message>
        <location line="+85"/>
        <source>To use the %s option</source>
        <translation>%s valiku kasutamine</translation>
    </message>
    <message>
        <location line="-77"/>
        <source>Error</source>
        <translation>Tõrge</translation>
    </message>
    <message>
        <location line="-35"/>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>rpcpassword=&lt;password&gt; peab sätete failis olema seadistatud:⏎
%s⏎
Kui seda faili ei ole, loo see ainult-omanikule-lugemiseks faili õigustes.</translation>
    </message>
</context>
</TS>