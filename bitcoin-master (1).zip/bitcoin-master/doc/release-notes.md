(note: this is a temporary file, to be added-to by anybody, and moved to
release-notes at release time)
